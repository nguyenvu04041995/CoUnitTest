$(document).ready(function() {
	var date = new Date();
	$('.today').html(date.getFullYear()+'年'+((date.getMonth()+1) < 10 ? '0'+(date.getMonth()+1) : (date.getMonth()+1)) +'月'+(date.getDate() < 10 ? '0'+date.getDate() : date.getDate())+'日');
	var totalPage = 19;
	var currentPage = 1;

	setPaging();
	$('.btn-pre').click(function() {
		--currentPage;
		setPaging();
	});

	$('.btn-next').click(function() {
		++currentPage;
		setPaging();
	});

	$('.btnToPage').click(function() {
		console.log(currentPage);
		console.log($('#toPage').val());
		if (parseInt($('#toPage').val()) <= 1) {
			currentPage = 1;
			setPaging();
			return false;
		}

		if(parseInt($('#toPage').val()) > totalPage) {
			currentPage = totalPage;
			setPaging();
			return false;
		}

		currentPage = $('#toPage').val();
		setPaging();
	});

	$('.btnUpdate').click(function() {
		for(var i = 0; i < $('.inputAction').length; i++) {
			var arr = ['c', 'C', 'd', 'D'];
			if (arr.indexOf($('.inputAction:eq('+i+')').val()) == -1) {
			$('#erorr').html('Message ID S3M0030E');
				return false;
			}

			if ($('.inputAction:eq('+i+')').val() == 'D' || $('.inputAction:eq('+i+')').val() == 'd') {
				if(confirm('を削除します。よろしいですか？')) {return true;}else{return false;}
				break;
			}
		}
	});

	function setPaging() {
		if (currentPage <= 1) {
			$('.btn-pre').prop('disabled', true);
		}else{
			$('.btn-pre').prop('disabled', false);
		}

		if(currentPage >= totalPage) {
			$('.btn-next').prop('disabled', true);
		}else{
			$('.btn-next').prop('disabled', false);
		}

		$('.current-page').html(currentPage+'/'+totalPage);
		$('#toPage').val(currentPage);
	}
});
package model.Bo;

import java.sql.SQLException;
import java.util.ArrayList;

import model.Bean.MakerNameMaster;
import model.Dao.MakerNameMasterDao;

/**
 * MakerNameMasterBo.java
 *
  * Date: May ‎25, ‎2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 *May ‎25, ‎2017     	    VuNQ2            Create
 */

public class MakerNameMasterBo {
	MakerNameMasterDao makerNameMasterDao=new MakerNameMasterDao();
  
	/**
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<MakerNameMaster>getListMakerNameMaster() throws SQLException{
		return makerNameMasterDao.getListMakerNameMaster();
		
	}
	/**
	 * @param manufactureCode
	 * @param manufactureName
	 * @return
	 * @throws SQLException
	 */
	public boolean AddMakerNameMaster(String manufactureCode, String manufactureName)throws SQLException {
		return makerNameMasterDao.AddMakerNameMaster(manufactureCode, manufactureName);
	}
	/**
	 * @param manufactureCode
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<MakerNameMaster>getListTimKiem_ManufactureCode(String manufactureCode) throws SQLException{
		return makerNameMasterDao.getListTimKiem_ManufactureCode(manufactureCode);
		
	}
	/**
	 * @param manufactureCode
	 * @param manufactureName
	 * @return
	 * @throws SQLException
	 */
	public boolean UpdateMakerNameMaster(String manufactureCode,String manufactureName) throws SQLException {

		return makerNameMasterDao.UpdateMakerNameMaster(manufactureCode,manufactureName);
	}
	/**
	 * @param manufactureCode
	 * @return
	 * @throws SQLException
	 */
	public boolean DeleteMakerNameMaster(String manufactureCode) throws SQLException {
		return makerNameMasterDao.DeleteMakerNameMaster(manufactureCode);
	}
	/**
	 * @param manufactureCode
	 * @return
	 * @throws SQLException
	 */
	public boolean CheckmanufactureCode(String manufactureCode) throws SQLException {
		return makerNameMasterDao.CheckmanufactureCode(manufactureCode);
	}
}

package Form;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.Bean.MakerNameMaster;

/**
 * 
 * MakerNameMasterForm.java
 *
 * Date: May ‎25, ‎2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 *May ‎25, ‎2017     	    VuNQ2            Create
 */

public class MakerNameMasterForm extends ActionForm {

	private static final long serialVersionUID = 1L;

	private String[] manufactureCode;
	private String[] manufactureName;
	private String action;
	private String submit;
	private MakerNameMaster makerNameMaster;

	/**
	 * @return the manufactureCode
	 */
	public String[] getManufactureCode() {
		return manufactureCode;
	}

	/**
	 * @param manufactureCodez
	 *            the manufactureCode to set
	 */
	public void setManufactureCode(String[] manufactureCode) {
		this.manufactureCode = manufactureCode;
	}

	/**
	 * @return the manufactureName
	 */
	public String[] getManufactureName() {
		return manufactureName;
	}

	/**
	 * @param manufactureName
	 *            the manufactureName to set
	 */
	public void setManufactureName(String[] manufactureName) {
		this.manufactureName = manufactureName;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the submit
	 */
	public String getSubmit() {
		return submit;
	}

	/**
	 * @param submit
	 *            the submit to set
	 */
	public void setSubmit(String submit) {
		this.submit = submit;
	}

	/**
	 * @return the makerNameMaster
	 */
	public MakerNameMaster getMakerNameMaster() {
		return makerNameMaster;
	}

	/**
	 * @param makerNameMaster
	 *            the makerNameMaster to set
	 */
	public void setMakerNameMaster(MakerNameMaster makerNameMaster) {
		this.makerNameMaster = makerNameMaster;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @param manufactureCode
	 * @param manufactureName
	 * @param action
	 * @param submit
	 * @param makerNameMaster
	 */
	public MakerNameMasterForm(String[] manufactureCode, String[] manufactureName, String action, String submit,
			MakerNameMaster makerNameMaster) {
		super();
		this.manufactureCode = manufactureCode;
		this.manufactureName = manufactureName;
		this.action = action;
		this.submit = submit;
		this.makerNameMaster = makerNameMaster;
	}

	/**
	 * 
	 */
	public MakerNameMasterForm() {
		super();
	}

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

}

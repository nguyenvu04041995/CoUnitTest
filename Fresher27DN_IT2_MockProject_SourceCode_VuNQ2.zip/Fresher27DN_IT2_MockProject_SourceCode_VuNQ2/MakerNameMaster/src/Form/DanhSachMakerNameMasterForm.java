package Form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.Bean.MakerNameMaster;

/**
 * 
 * DanhSachMakerNameMasterForm.java
 *
 * Date: May ‎25, ‎2017
 *
 * Copyright
 *
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- May
 * ‎25, ‎2017 VuNQ2 Create
 */

public class DanhSachMakerNameMasterForm extends ActionForm {

	/**
	 * @return the thongBao
	 */
	public String getThongBao() {
		return thongBao;
	}

	/**
	 * @param thongBao the thongBao to set
	 */
	public void setThongBao(String thongBao) {
		this.thongBao = thongBao;
	}

	private static final long serialVersionUID = 1L;

	private String submitUpdate;
	private String[] updateChar;
	private String[] manufactureName;
	private String searchmanufactureCode;
	private String[] manufactureCode1;
	private int page;
	private int rowPerPage;

	private int countRows;
	private int totalPages;
	private int number;
	private ArrayList<MakerNameMaster> listMakerNameMaster;
	private String thongBao;
	/**
	 * @return the submitUpdate
	 */
	public String getSubmitUpdate() {
		return submitUpdate;
	}

	/**
	 * @param submitUpdate
	 *            the submitUpdate to set
	 */
	public void setSubmitUpdate(String submitUpdate) {
		this.submitUpdate = submitUpdate;
	}

	/**
	 * @return the updateChar
	 */
	public String[] getUpdateChar() {
		return updateChar;
	}

	/**
	 * @param updateChar
	 *            the updateChar to set
	 */
	public void setUpdateChar(String[] updateChar) {
		this.updateChar = updateChar;
	}

	/**
	 * @return the manufactureName
	 */
	public String[] getManufactureName() {
		return manufactureName;
	}

	/**
	 * @param manufactureName
	 *            the manufactureName to set
	 */
	public void setManufactureName(String[] manufactureName) {
		this.manufactureName = manufactureName;
	}

	/**
	 * @return the searchmanufactureCode
	 */
	public String getSearchmanufactureCode() {
		return searchmanufactureCode;
	}

	/**
	 * @param searchmanufactureCode
	 *            the searchmanufactureCode to set
	 */
	public void setSearchmanufactureCode(String searchmanufactureCode) {
		this.searchmanufactureCode = searchmanufactureCode;
	}

	/**
	 * @return the manufactureCode1
	 */
	public String[] getManufactureCode1() {
		return manufactureCode1;
	}

	/**
	 * @param manufactureCode1
	 *            the manufactureCode1 to set
	 */
	public void setManufactureCode1(String[] manufactureCode1) {
		this.manufactureCode1 = manufactureCode1;
	}

	/**
	 * @return the page
	 */
	public int getPage() {
		return page;
	}

	/**
	 * @param page
	 *            the page to set
	 */
	public void setPage(int page) {
		this.page = page;
	}

	/**
	 * @return the rowPerPage
	 */
	public int getRowPerPage() {
		return rowPerPage;
	}

	/**
	 * @param rowPerPage
	 *            the rowPerPage to set
	 */
	public void setRowPerPage(int rowPerPage) {
		this.rowPerPage = rowPerPage;
	}

	/**
	 * @return the countRows
	 */
	public int getCountRows() {
		return countRows;
	}

	/**
	 * @param countRows
	 *            the countRows to set
	 */
	public void setCountRows(int countRows) {
		this.countRows = countRows;
	}

	/**
	 * @return the totalPages
	 */
	public int getTotalPages() {
		return totalPages;
	}

	/**
	 * @param totalPages
	 *            the totalPages to set
	 */
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	/**
	 * @return the number
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * @param number
	 *            the number to set
	 */
	public void setNumber(int number) {
		this.number = number;
	}

	/**
	 * @return the listMakerNameMaster
	 */
	public ArrayList<MakerNameMaster> getListMakerNameMaster() {
		return listMakerNameMaster;
	}

	/**
	 * @param listMakerNameMaster
	 *            the listMakerNameMaster to set
	 */
	public void setListMakerNameMaster(ArrayList<MakerNameMaster> listMakerNameMaster) {
		this.listMakerNameMaster = listMakerNameMaster;
	}

	
	
	
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @param submitUpdate
	 * @param updateChar
	 * @param manufactureName
	 * @param searchmanufactureCode
	 * @param manufactureCode1
	 * @param page
	 * @param rowPerPage
	 * @param countRows
	 * @param totalPages
	 * @param number
	 * @param listMakerNameMaster
	 */
	public DanhSachMakerNameMasterForm(String submitUpdate, String[] updateChar, String[] manufactureName,
			String searchmanufactureCode, String[] manufactureCode1, int page, int rowPerPage, int countRows,
			int totalPages, int number, ArrayList<MakerNameMaster> listMakerNameMaster) {
		super();
		this.submitUpdate = submitUpdate;
		this.updateChar = updateChar;
		this.manufactureName = manufactureName;
		this.searchmanufactureCode = searchmanufactureCode;
		this.manufactureCode1 = manufactureCode1;
		this.page = page;
		this.rowPerPage = rowPerPage;
		this.countRows = countRows;
		this.totalPages = totalPages;
		this.number = number;
		this.listMakerNameMaster = listMakerNameMaster;
	
	}

	/**
	 * 
	 */
	public DanhSachMakerNameMasterForm() {
		super();
	}

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

}
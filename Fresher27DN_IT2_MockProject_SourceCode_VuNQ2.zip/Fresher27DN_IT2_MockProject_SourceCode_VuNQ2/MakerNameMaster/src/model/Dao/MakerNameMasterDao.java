package model.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Bean.MakerNameMaster;




/**
 * MakerNameMasterDao.java
 *
 * Date: May ‎25, ‎2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 *May ‎25, ‎2017     	    VuNQ2            Create
 */
public class MakerNameMasterDao {

	/***
	 * Get List MakerNameMaster
	 * 
	 * @return
	 * @throws Exception
	 */
	public ArrayList<MakerNameMaster> getListMakerNameMaster() throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		String sql = "select * from MakerNameMaster";
		ResultSet rs = null;
		Statement stmt = null;

		try {
			stmt = ConnectData.connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			throw new SQLException("Error occur" + e1.getMessage());
		}

		ArrayList<MakerNameMaster> list = new ArrayList<>();
		MakerNameMaster makerNameMaster;
		try {
			while (rs.next()) {
				makerNameMaster = new MakerNameMaster();
				makerNameMaster.setManufacturerCode(rs.getString("ManufactureCode"));
				makerNameMaster.setManufactureName(rs.getString("ManufactureName").trim());

				list.add(makerNameMaster);
			}
		} catch (SQLException e) {
			throw new SQLException("Error occur" + e.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (ConnectData.connection != null) {
					ConnectData.connection.close();
				}
			} catch (SQLException e1) {
				throw new SQLException("Error occur" + e1.getMessage());
			}
		}
		return list;
	}

	/***
	 * Add MakerNameMaster
	 * 
	 * @param manufactureCode
	 * @param manufactureName
	 */
	public boolean AddMakerNameMaster(String manufactureCode, String manufactureName) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		Statement stmt = null;
		String sql = String.format(
				"INSERT INTO MakerNameMaster(ManufactureCode,ManufactureName) " + " VALUES ( '%s','%s')",
				manufactureCode, manufactureName);
		try {
			stmt = ConnectData.connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {

				if (stmt != null) {
					stmt.close();
				}
				if (ConnectData.connection != null) {
					ConnectData.connection.close();
				}
			} catch (SQLException e1) {
				throw new SQLException("Error occur" + e1.getMessage());
			}
		}

		return false;

	}

	/***
	 * Update MakerNameMaster
	 * 
	 * @param manufactureCode
	 * @param manufactureName
	 * @throws SQLException
	 */
	public boolean UpdateMakerNameMaster(String manufactureCode, String manufactureName) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		PreparedStatement prtmm = null;
		try {
			String sqlQuery = "update MakerNameMaster set ManufactureName=?" + " where ManufactureCode = ?;";

			prtmm = ConnectData.connection.prepareStatement(sqlQuery);
			// set code.

			prtmm.setString(1, manufactureName);

			prtmm.setString(2, manufactureCode);

			prtmm.executeUpdate();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			try {
				prtmm.close();
				ConnectData.connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
				throw new SQLException();
			}
		}
		return false;

	}

	/***
	 * Delete MakerNameMaster
	 * 
	 * @param manufactureCode
	 * @return
	 * @throws SQLException
	 */
	public boolean DeleteMakerNameMaster(String manufactureCode) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		PreparedStatement prtmm = null;
		try {
			String sqlQuery = "delete FROM MakerNameMaster where ManufactureCode = ?;";
			prtmm = ConnectData.connection.prepareStatement(sqlQuery);
			prtmm.setString(1, manufactureCode);
			prtmm.executeUpdate();
		} catch (Exception e) {

			throw new SQLException("Error occur" + e.getMessage());
		} finally {
			try {
				prtmm.close();
			} catch (SQLException e) {

				e.printStackTrace();
				throw new SQLException();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return false;

	}

	/***
	 * Search MakerNameMaster
	 * 
	 * @param manufactureCode
	 * @return
	 * @throws SQLException
	 */
	/*public ArrayList<MakerNameMaster> getListTimKiem_ManufactureCode(String manufactureCode) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		String sql;
		PreparedStatement prtmm = null;
		// Check empty input values to show all
		if (manufactureCode == "") {
			sql = "select * from MakerNameMaster ";
		} else {
			// If there is a non-empty field, then the value corresponding to
			// that field is displayed
			if (manufactureCode == "") {
				manufactureCode = null;
			}
			sql = "select * from MakerNameMaster where ManufactureCode like N'%" + manufactureCode + "%'";
		}
		ResultSet rs = null;
		try {
			prtmm = ConnectData.connection.prepareStatement(sql);

			rs = prtmm.executeQuery();

		} catch (SQLException e) {
			throw new SQLException("Error occur: " + e.getMessage());
		}
		ArrayList<MakerNameMaster> list = new ArrayList<MakerNameMaster>();
		MakerNameMaster makerNameMaster;
		try {
			while (rs.next()) {
				makerNameMaster = new MakerNameMaster();
				makerNameMaster.setManufacturerCode(rs.getString("ManufactureCode"));
				makerNameMaster.setManufactureName(rs.getString("ManufactureName"));
				list.add(makerNameMaster);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();j
				}
				if (prtmm != null) {
					prtmm.close();
				}
				if (ConnectData.connection != null) {
					ConnectData.connection.close();
				}
			} catch (SQLException e1) {
				throw new SQLException("Error occur" + e1.getMessage());
			}
		}
		return list;
	}*/

	/****
	 * Check existence of MakerNameMarter
	 * 
	 * @param manufactureCode
	 * @return
	 * @throws SQLException
	 */
	public boolean CheckmanufactureCode(String manufactureCode) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		String sql = String.format("SELECT * from MakerNameMaster WHERE ManufactureCode = '"+manufactureCode+"'");
		System.out.println(sql);
		ResultSet rs = null;
		PreparedStatement prtmm = null;
		try {
			prtmm = ConnectData.connection.prepareStatement(sql);
		//	prtmm.setString(1, manufactureCode);
			rs = prtmm.executeQuery();
			if (rs.next()) {
				System.out.println("zzzzzzzzzzzzzz");
				return true;
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prtmm != null) {
					prtmm.close();
				}
				if (ConnectData.connection != null) {
					ConnectData.connection.close();
				}
			} catch (SQLException e1) {
				throw new SQLException("Error occur" + e1.getMessage());
			}
		}
		return false;
	}

	public int getCountRows(String name) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		Statement stmt = null;
		int countRows = 0;
		String sqlWhere = "";
		// find follow name 1
		if (name == null || name.length() == 0) {

		} else {
			sqlWhere = sqlWhere + " AND ManufactureCode LIKE '%" + name + "%' ";
		}

		String sql = "select count(*) as count FROM MakerNameMaster p WHERE 1=1"
				+ sqlWhere;
		try {

			stmt = ConnectData.connection.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				countRows = rs.getInt("count");
			}

		} catch (SQLException e) {
			throw new SQLException();
		}
		return countRows;
	}

	
	public ArrayList<MakerNameMaster> getListMakerNameMaster(String manufactureCode, int page, int rowPerPage) {
		ConnectData.connection = ConnectData.getconnect();
		int start = (page - 1) * rowPerPage;
		ArrayList<MakerNameMaster> listMakerNameMaster = new ArrayList<>();
	
		PreparedStatement prtmm = null;
		try {
			String sqlWhere = "";
			// find follow name
			if (manufactureCode == null || manufactureCode.length() == 0) {

			} else {
				sqlWhere = sqlWhere + " AND ManufactureCode LIKE '%" + manufactureCode
						+ "%' ";
			}

			String sqlQuery = "select ManufactureCode,ManufactureName"
					+ " FROM MakerNameMaster p where 1=1" + sqlWhere + " ";

			sqlQuery += " ORDER BY ManufactureCode OFFSET " + start + " ROWS FETCH NEXT "
					+ rowPerPage + " ROWS ONLY ;";

			prtmm = ConnectData.connection.prepareStatement(sqlQuery);
			ResultSet rs = prtmm.executeQuery();
			MakerNameMaster makerNameMaster;
			int number=0;
			while (rs.next()) {
				
					number++;
					manufactureCode = rs.getString("ManufactureCode").trim();
					String manufactureName = rs.getString("ManufactureName").trim();
					System.out.println("number"+number);
					 makerNameMaster = new MakerNameMaster(number,manufactureCode, manufactureName);
					listMakerNameMaster.add(makerNameMaster);

			}
			
		} catch (Exception e) {
		
			
		}

		return listMakerNameMaster;
		
	}

	public boolean isExist(String manufactureCode) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		boolean isExist = false;
		String sqlQuery = "SELECT * FROM MakerNameMaster WHERE ManufactureCode='"
				+ manufactureCode + "'";
		PreparedStatement prtmm = null;
		ResultSet rs = null;
		prtmm = ConnectData.connection.prepareStatement(sqlQuery);
		rs = prtmm.executeQuery();
		if (rs.next()) {
			isExist = true;
		} else {
			isExist = false;
		}
		prtmm.close();
		ConnectData.connection.close();
		return isExist;
	}
	

}

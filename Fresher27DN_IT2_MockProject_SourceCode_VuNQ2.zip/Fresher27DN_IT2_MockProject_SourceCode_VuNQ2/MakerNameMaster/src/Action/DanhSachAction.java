package Action;

import static Common.Constants.PAGE;
import static Common.Constants.ROW_PER_PAGE;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import Form.DanhSachMakerNameMasterForm;
import model.Bean.MakerNameMaster;
import model.Bo.MakerNameMasterBo;

import Common.StringProcess;

public class DanhSachAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");

		ActionErrors actionErrors = new ActionErrors();
		DanhSachMakerNameMasterForm danhSachMakerNameMasterForm = (DanhSachMakerNameMasterForm) form;
		StringProcess stringProcess = new StringProcess();

		MakerNameMasterBo makerNameMasterBo = new MakerNameMasterBo();
		int page = 1;

		// Number of lines per page
		int rowPerPage = 10;

		// Count the number of lines
		int countRows = 0;

		// Count the total number of pages
		int totalPages = 0;

		// Get a few page values
		String pageStr = "";

		// Get the number of lines to display on a page
		String rowPerPageStr = "";

		// Get parameter of page number n and row number on page
		pageStr = stringProcess.urlEndcoder(request.getParameter(PAGE));
		rowPerPageStr = stringProcess.urlEndcoder(request.getParameter(ROW_PER_PAGE));

		// Valid parameter
		if (pageStr != null && pageStr != "" && stringProcess.isNumber(pageStr)) {
			page = Integer.valueOf(pageStr);
		}
		if (rowPerPageStr != null && rowPerPageStr != "" && stringProcess.isNumber(rowPerPageStr)) {
			rowPerPage = Integer.valueOf(rowPerPageStr);
		}
		String searchmanufactureCode = danhSachMakerNameMasterForm.getSearchmanufactureCode();
		if (searchmanufactureCode != null) {
			searchmanufactureCode = searchmanufactureCode.trim();
		}
		
		saveErrors(request, actionErrors);

		if (danhSachMakerNameMasterForm.getSubmitUpdate() != null) {
			String[] updateChar = danhSachMakerNameMasterForm.getUpdateChar();
			String[] manufactureCode1 = danhSachMakerNameMasterForm.getManufactureCode1();
			String[] manufactureName = danhSachMakerNameMasterForm.getManufactureName();
			for (int i = 0; i < updateChar.length; i++) {
				if (!updateChar[i].equals("")) {

					// Failure condition input item 26 C D
					if (StringProcess.isItem26(updateChar[i]) == true) {

						// if item 26 is C then continue valid
						if (updateChar[i].equals("c") || updateChar[i].equals("C")) {
							if (StringProcess.maxlengthManufactureName(danhSachMakerNameMasterForm.getManufactureName())) {
								actionErrors.add("msvError4",
										new ActionMessage("error.msv4.maxlengthManufactureName10character"));
                                    //kiem tr ki tu dc biet
							} else if (StringProcess.isSpecialCharactersManufactureName(
									danhSachMakerNameMasterForm.getManufactureName())) {
								
								actionErrors.add("msvError6",new ActionMessage("error.msv3.ManufactureName.Characters"));
							}
							else {
							
								makerNameMasterBo.UpdateMakerNameMaster(manufactureCode1[i], manufactureName[i]);

							}
							saveErrors(request, actionErrors);

						}
						if (updateChar[i].equals("d") || updateChar[i].equals("D")) {
							makerNameMasterBo.DeleteMakerNameMaster(manufactureCode1[i]);
						}
					}
				}
			}

		}

		// get number line
		countRows = makerNameMasterBo.getCountRows(searchmanufactureCode);

		// Clear list + reset list.

		totalPages = (int) (Math.ceil((double) countRows / rowPerPage));
		// Get record follow page.
		ArrayList<MakerNameMaster> listMakerNameMaster;
		listMakerNameMaster = makerNameMasterBo.getListMakerNameMaster(searchmanufactureCode, page, rowPerPage);

		if (listMakerNameMaster.size() == 0) {
			actionErrors.add("errorList", new ActionMessage("error.list.null"));
			saveErrors(request, actionErrors);
		}

		danhSachMakerNameMasterForm.setListMakerNameMaster(listMakerNameMaster);
		danhSachMakerNameMasterForm.setPage(page);
		danhSachMakerNameMasterForm.setRowPerPage(rowPerPage);
		danhSachMakerNameMasterForm.setCountRows(countRows);
		danhSachMakerNameMasterForm.setTotalPages(totalPages);

		if (actionErrors.size() > 0) {
			return mapping.findForward("listMakerNameMaster");
		}
		return mapping.findForward("listMakerNameMaster");
	}

}

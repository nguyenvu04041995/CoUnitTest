package Action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import Form.MakerNameMasterForm;
import Common.StringProcess;
import model.Bo.MakerNameMasterBo;

/**
 * AddMakerNameMaster.java
 *
 * Date: May ‎25, ‎2017
 *
 * Copyright
 *
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- May
 * ‎25, ‎2017 VuNQ2 Create
 */

public class AddMakerNameMaster extends Action {
	@Override

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		MakerNameMasterForm makerNameMasterForm = (MakerNameMasterForm) form;
		MakerNameMasterBo makerNameMasterBo = new MakerNameMasterBo();
		ActionErrors actionErrors = new ActionErrors();

		// Getting input errors
		if ("登録(U)".equals(makerNameMasterForm.getSubmit())) {
			if (!StringProcess.isValidNameMasterForm(makerNameMasterForm.getManufactureCode())) {
				actionErrors.add("msvError1", new ActionMessage("error.msv1.ManufactureCode.blank"));
			}
			if (StringProcess.maxlengthNameMasterForm(makerNameMasterForm.getManufactureCode())) {
				actionErrors.add("msvError2", new ActionMessage("error.msv2.maxlengthManufactureCode2character"));
			}
			if (StringProcess.getValidSpaceFirstLastString(makerNameMasterForm.getManufactureCode())) {
				actionErrors.add("msvError3", new ActionMessage("error.msv3.ManufactureCode.space"));
			}
			if (StringProcess.isSpecialCharacters(makerNameMasterForm.getManufactureCode())) {
				actionErrors.add("msvError5", new ActionMessage("error.msv3.ManufactureCode.Characters"));
			}
			if (StringProcess.maxlengthManufactureName(makerNameMasterForm.getManufactureName())) {
				actionErrors.add("msvError4", new ActionMessage("error.msv4.maxlengthManufactureName10character"));
			}
			if (StringProcess.isSpecialCharactersManufactureName(makerNameMasterForm.getManufactureName())) {
				actionErrors.add("msvError6", new ActionMessage("error.msv3.ManufactureName.Characters"));
			}
			saveErrors(request, actionErrors);
			if (actionErrors.size() > 0) {
				return mapping.findForward("AddMakerNameMaster");
			}
			if (actionErrors.isEmpty()) {
				String[] manufactureCode = makerNameMasterForm.getManufactureCode();
				String[] manufactureName = makerNameMasterForm.getManufactureName();
		
				int s = 0;
				for (int i = 0; i < 10; i++) {
					if(manufactureCode[i]=="")
					{
						
						System.out.println(manufactureCode[i]);
					}
					else
					if (makerNameMasterBo.CheckmanufactureCode(manufactureCode[i])) {
						s = 1;
						System.out.println(s);	
					} else {
							s = 0;
					}
					if (s == 0) {
						makerNameMasterBo.AddMakerNameMaster(manufactureCode[i], manufactureName[i]);
					}

				}
				if (s == 1) {
					actionErrors.add("err", new ActionMessage("error.ManufactureCode.trung"));
					saveErrors(request, actionErrors);
					return mapping.findForward("AddMakerNameMaster");
				}else
				if (s == 0) {

					return mapping.findForward("AddMakerNameMasterxong");
				}
			//d ton tai pai input sau
			}
		} else {
			String[] manufactureCode = { "", "", "", "", "", "", "", "", "", "" };
			String[] manufactureName = { "", "", "", "", "", "", "", "", "", "" };
			makerNameMasterForm.setManufactureCode(manufactureCode);
			makerNameMasterForm.setManufactureName(manufactureName);
		}

		return mapping.findForward("AddMakerNameMaster");
	}
}
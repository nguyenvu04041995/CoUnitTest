/*package Test;

import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import junit.framework.TestCase;

import model.Dao.MakerNameMasterDao;
import model.Bean.*;

public class MakerNameMasterTest extends TestCase {
	MakerNameMasterDao makerNameMasterDao;
	protected String manufactureCode;
	protected String manufactureName;

	protected ArrayList<MakerNameMaster> arrSearchMakerNameMasterExpected;
	protected ArrayList<MakerNameMaster> arrSearchMakerNameMasterActual;
	protected ArrayList<MakerNameMaster> arrAddMakerNameMasterExpected;
	protected ArrayList<MakerNameMaster> arrAddMakerNameMasterActual;
	protected ArrayList<MakerNameMaster> arrListMakerNameMasterExpected;
	protected ArrayList<MakerNameMaster> arrListMakerNameMasterActual;
	protected boolean resultDeleteActual;
	protected boolean resultUpdateActual;
	protected boolean resultAddActual;
	protected boolean ConnectActual;

	@Before
	public void setUp() throws Exception {

		makerNameMasterDao = new MakerNameMasterDao();
		manufactureCode = "Ma";

		// Create result for function SearchMakerNameMaster
		arrSearchMakerNameMasterExpected = new ArrayList<MakerNameMaster>();
		arrSearchMakerNameMasterExpected.add(new MakerNameMaster("Ma", "aa"));
		arrSearchMakerNameMasterExpected.add(new MakerNameMaster("", ""));
		arrSearchMakerNameMasterActual = makerNameMasterDao.getListTimKiem_ManufactureCode(manufactureCode);

		// Create result for function getListMakerNameMaster
		arrListMakerNameMasterExpected = new ArrayList<MakerNameMaster>();
		arrListMakerNameMasterExpected.add(new MakerNameMaster("1", "qw"));
		arrListMakerNameMasterExpected.add(new MakerNameMaster("2", "aa"));
		arrListMakerNameMasterExpected.add(new MakerNameMaster("3", "as"));
		arrListMakerNameMasterActual = makerNameMasterDao.getListMakerNameMaster();

		// Create result for function deleteMakerNameMaster
		manufactureCode = "M1";
		resultDeleteActual = makerNameMasterDao.DeleteMakerNameMaster(manufactureCode);

		// Create result for function updateTrainer
		
		 * manufactureCode = "M1"; resultUpdateActual =
		 * makerNameMasterDao.UpdateMakerNameMaster(new MakerNameMaster("",
		 * ""));
		 
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSearchMakerNameMaster() {
		assertEquals(arrSearchMakerNameMasterExpected.get(0).getManufactureCode(),
				arrSearchMakerNameMasterActual.get(0).getManufactureCode());

		assertEquals(arrSearchMakerNameMasterExpected.get(0).getManufactureName(),
				arrSearchMakerNameMasterActual.get(0).getManufactureName());

	}

	@Test
	public void testgetListMakerNameMaster() {
		assertEquals(arrListMakerNameMasterExpected.get(0).getManufactureCode(),
				arrSearchMakerNameMasterActual.get(0).getManufactureCode());

		assertEquals(arrListMakerNameMasterExpected.get(0).getManufactureName(),
				arrSearchMakerNameMasterActual.get(0).getManufactureName());

	}

	*//**
	 * Test function deleteTrainer
	 *//*
	@Test
	public void testDeleteTrainer() {
		assertFalse(resultDeleteActual);
	}

}
*/
package Common;

/**
 * ListAutCarnmAction.java
 *
 * Version 1.0
 *
 * Date: May 18, 2017
 *
 * Copyright HueTT8
 *
 * Modification Logs: 
 * DATE				AUTHOR			DESCRIPTION
 * ----------------------------------------------------------------------- 
 * May 18, 2017 	HueTT8 			Create
 * 
 */

  //Constants 
 public final class Constants {
	
	
	//regex date yyyy-mm-dd
	public static final String DATE_PATTERN = "((19|20)\\d\\d)-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])";
	
	//number page present
	public static final String PAGE = "page";
	
	// number line on page
	public static final String ROW_PER_PAGE = "rowPerPage";
	
	//  file download
	public static final String PATH_DOWNLOAD = "d:\\Directory\\Download\\";
	
	//file download
	public static final String PATH_TEMPLATE = "d:\\Directory\\Template\\";
	
}

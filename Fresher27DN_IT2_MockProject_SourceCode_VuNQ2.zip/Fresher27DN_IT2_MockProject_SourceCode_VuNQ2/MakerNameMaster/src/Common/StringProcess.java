package Common;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ListAutCarnmAction.java
 *
 * Version 1.0
 *
 * Date: May 18, 2017
 *
 * Copyright HueTT8
 *
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- May
 * 18, 2017  Create
 * 
 */

public class StringProcess {
	//Bien gan cho gia tri
	private Pattern pattern;
	
	//Bien de check true false.
	private Matcher matcher;
	//Variables regex condition for value of type INTERGER.
		private static final String INTEGER = "\\d+";
	/**
	 * Check value input C D ?.
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isItem26(String s) {
		String regex1 = "c";
		String regex2 = "C";
		String regex3 = "d";
		String regex4 = "D";
		if (s.matches(regex1) || s.matches(regex2) || s.matches(regex3) || s.matches(regex4)) {
			return true;
		} else {
			return false;
		}
	}
	public String urlEndcoder(String urlStr) {
		String encodedUrl = "";
		String url = "";

		if (urlStr != null) {
			url = urlStr;
		}
		try {
			encodedUrl = URLEncoder.encode(url, "UTF-8");
			return encodedUrl;
		} catch (UnsupportedEncodingException e) {
			return encodedUrl;
		}
	}
	public static boolean isValidNameMasterForm(String[] manufactureCode) {
	for (String factureCode : manufactureCode) {
			if (factureCode.trim().length() != 0) {
				return true;
			}
		}
	return false;
		
		
	}

	public static boolean maxlengthNameMasterForm(String[] manufactureCode) {
		for (String factureCode : manufactureCode) {
			if (factureCode.length() > 2) {
				return true;
			}
		}
		return false;
	}

	public static boolean getValidSpaceFirstLastString(String[] manufactureCode) {
		for (String factureCode : manufactureCode) {
			String s1 = factureCode.trim();
			String s2 = factureCode.replaceAll("  ", " ");
			if ((factureCode.length() > s1.length()) && (factureCode.length() > s2.length())) {
				return true;

			}
		}
		return false;
	}
	/**
	 * Check whether the input value is an integer or not.
	 * @param pageStr
	 * @return boolean
	 */
	public boolean isNumber(String pageStr) {
		boolean re = false;
		pattern = Pattern.compile(INTEGER);
		matcher = pattern.matcher(pageStr);
		re = matcher.matches();
		return re;
	}
	public static boolean maxlengthManufactureName(String[] manufactureName) {
		for (String factureCode : manufactureName) {
			if (factureCode.length() > 10) {
				return true;
			}
		}
		return false;
	}
	public static boolean isSpecialCharacters(String[] manufactureCode) {
		for (String factureCode : manufactureCode) {
			factureCode=factureCode.trim().replaceAll("\\s+", " ");;
			String regex = (".*[\"\\.&,@!?%'$()/\\\\ \\_<>].*");
			if(factureCode.matches(regex)){
				return true;
			}
		}
		return false;
	}
	public static boolean isSpecialCharactersManufactureName(String[] manufactureName) {
		for (String factureCode : manufactureName) {
			factureCode=factureCode.trim().replaceAll("\\s+", " ");;
			String regex = (".*[\"\\.&,@!?%'$()/\\\\ \\_<>].*");
			if(factureCode.matches(regex)){
				return true;
			}
		}
		return false;
	}

	/*	public static String chuanHoa(String str) {
				str = str.trim();
				str = str.replaceAll("\\s+", " ");
				return str;
			}
			 
		public static boolean isSpecialCharacters(String str) {
				str = chuanHoa(str);
				String regex = (".*[\"\\.&,@!?%'$()/\\\\ \\_<>].*");
				return (str.matches(regex)) ? true : false;
			} 
*/
	
	
	
}
